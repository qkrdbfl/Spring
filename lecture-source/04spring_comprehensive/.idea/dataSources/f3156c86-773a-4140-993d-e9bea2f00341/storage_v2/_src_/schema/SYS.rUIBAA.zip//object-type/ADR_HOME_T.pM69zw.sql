create TYPE adr_home_t FORCE AS OBJECT
(
  product_type          VARCHAR2(8),                        /* product type */
  product_id            VARCHAR2(30),                         /* product id */
  instance_id           VARCHAR2(30),                        /* instance id */
  precedence            INTEGER,       /* precedence level of this adr home */
  adr_id                INTEGER,              /* hash value of the adr home */


-- **********************************************************************
-- Construct an ADR home object representing ADR home at a location
-- described by application specific naming
-- **********************************************************************

  CONSTRUCTOR FUNCTION adr_home_t
  (
    SELF IN OUT NOCOPY  adr_home_t,
    product_type        VARCHAR2,
    product_id          VARCHAR2,
    instance_id         VARCHAR2,
    precedence          INTEGER
  )
  RETURN SELF AS RESULT
);
/

