create package dbms_fs AUTHID CURRENT_USER AS

-- DE-HEAD  <- tell SED where to cut when generating fixed package

  -- Creates a file system of type specified by fstype and of name fsname
  -- This is similar to mkfs on Unix
  --
  -- fstype - file system type
  -- fsname - name of the file system
  -- fsoptions - a comma separated file system create options
  --
  PROCEDURE make_oracle_fs (fstype  IN varchar2,
                            fsname  IN varchar2,
                            fsoptions  IN varchar2);

  -- Mount an Oracle file system on the specified mount point
  -- This is similar to mount on Unix
  --
  -- fstype - file system type
  -- fsname - name of the file system
  -- mount_point - directory where the file system should be mounted
  -- mount_options - a comma separated mount options
  --
  PROCEDURE mount_oracle_fs (fstype  IN varchar2,
                             fsname  IN varchar2,
                             mount_point IN varchar2,
                             mount_options  IN varchar2);

  -- Unmount an Oracle file system on the specified mount point
  -- This is similar to mount on Unix
  --
  -- fsname - name of the file system
  -- mount_point - directory where the file system is mounted
  -- umount options - options used for unmount - force option
  --
  PROCEDURE unmount_oracle_fs (fsname  IN varchar2,
                               mount_point  IN varchar2,
                               umount_options IN varchar2 default NULL);


  -- Destroys a file system of type specified by fstype and of name fsname
  -- This is similar to zfs destroy <filesystem>
  --
  -- fstype - file system type
  -- fsname - name of the file system
  --
  PROCEDURE destroy_oracle_fs (fstype  IN varchar2,
                               fsname  IN varchar2);

-------------------------------------------------------------------------------

pragma TIMESTAMP('2011-02-14:12:00:00');

-------------------------------------------------------------------------------


end;

-- CUT_HERE    <- tell sed where to chop off the rest
/

