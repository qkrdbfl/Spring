create FUNCTION dbj_long_name (shortname VARCHAR2) RETURN VARCHAR2
as language java name
    'oracle.aurora.rdbms.DbmsJava.longNameForSQL(java.lang.String)
          return java.lang.String';
/

