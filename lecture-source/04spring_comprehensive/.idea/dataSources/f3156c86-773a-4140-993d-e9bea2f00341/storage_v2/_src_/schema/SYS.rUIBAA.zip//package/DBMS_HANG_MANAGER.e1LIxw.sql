create PACKAGE dbms_hang_manager AS

  -- parameter names
  RESOLUTION_SCOPE           CONSTANT VARCHAR2(40) := 'resolution scope';
  SENSITIVITY                CONSTANt VARCHAR2(40) := 'sensitivity';
  BASE_FILE_SIZE_LIMIT       CONSTANT VARCHAR2(40) := 'base file size limit';
  BASE_FILE_SET_COUNT        CONSTANT VARCHAR2(40) := 'base file set count';
  LWS_FILE_SIZE_LIMIT
      CONSTANT VARCHAR2(40) := 'long waiting session file size limit';
  LWS_FILE_SET_COUNT
      CONSTANT VARCHAR2(40) := 'long waiting session file set count';

  -- resolution scope values
  RESOLUTION_SCOPE_OFF       CONSTANT VARCHAR2(20) := 'OFF';
  RESOLUTION_SCOPE_PROCESS   CONSTANT VARCHAR2(20) := 'PROCESS';
  RESOLUTION_SCOPE_INSTANCE  CONSTANT VARCHAR2(20) := 'INSTANCE';

  -- sensitivity values
  SENSITIVITY_NORMAL         CONSTANT VARCHAR2(20) := 'NORMAL';
  SENSITIVITY_HIGH           CONSTANT VARCHAR2(20) := 'HIGH';

  PROCEDURE set(pname IN VARCHAR2, pvalue IN VARCHAR2);

  -- Error code for invalid user input
  errnum_input_error                CONSTANT NUMBER := -32706;

  -- Error code when DB experiences errors when setting/retrieving a parameter
  errnum_internal_error             CONSTANT NUMBER := -32707;

  -- Error code for unsupported instance types
  errnum_unsupported_error          CONSTANT NUMBER := -32708;

  exception_input_error             EXCEPTION;
  PRAGMA EXCEPTION_INIT(exception_input_error,         -32706);
  exception_internal_error          EXCEPTION;
  PRAGMA EXCEPTION_INIT(exception_internal_error,      -32707);
  exception_unsupported_error       EXCEPTION;
  PRAGMA EXCEPTION_INIT(exception_unsupported_error,   -32708);

END dbms_hang_manager;
/

