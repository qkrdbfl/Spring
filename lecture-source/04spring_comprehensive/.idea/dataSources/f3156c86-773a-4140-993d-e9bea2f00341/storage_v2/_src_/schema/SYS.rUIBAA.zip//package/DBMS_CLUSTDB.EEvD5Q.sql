create PACKAGE dbms_clustdb AS

PROCEDURE validate;

END dbms_clustdb;
/

