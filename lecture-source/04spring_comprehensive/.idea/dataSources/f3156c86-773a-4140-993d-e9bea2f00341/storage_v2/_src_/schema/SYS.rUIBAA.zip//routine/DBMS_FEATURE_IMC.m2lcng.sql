create procedure DBMS_FEATURE_IMC(
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
AS
    feature_usage               varchar2(1000);
    num_tab                     number;
    num_tab_part                number;
    num_tab_subpart             number;
    num_tab_cc                  number;
    num_tab_part_cc             number;
    num_segs                    number;
    inmemory_size_value         number;

BEGIN
    feature_boolean             := 0;
    aux_count                   := 0;
    inmemory_size_value         := 0;

    -- check if any segments are enabled for in-memory
    execute immediate
       'select count(*) from dba_tables where ' ||
       'inmemory_compression is not null and ' ||
       'not (tablespace_name in (''SYSTEM'', ''SYSAUX'') ' ||
       'and owner like ''SYS'')'
    into num_tab;

    execute immediate
       'select count(*) from dba_tab_partitions where ' ||
       'inmemory_compression is not null and ' ||
       'not (tablespace_name in (''SYSTEM'', ''SYSAUX'') ' ||
       'and table_owner like ''SYS'') and table_name ' ||
       'not like ''BIN$%'''
    into num_tab_part;

    execute immediate
       'select count(*) from dba_tab_subpartitions where ' ||
       'inmemory_compression is not null and ' ||
       'not (tablespace_name in (''SYSTEM'', ''SYSAUX'') ' ||
       'and table_owner like ''SYS'') and table_name ' ||
       'not like ''BIN$%'''
    into num_tab_subpart;

    -- check if any segments were enabled for cellmemory
    -- note some tables may show up twice as in-memory and cellmemory
    execute immediate
       'select count(*) from dba_tables where ' ||
       'cellmemory like ''MEMCOMPRESS%'' and ' ||
       'not (tablespace_name in (''SYSTEM'', ''SYSAUX'') ' ||
       'and owner like ''SYS'')'
    into num_tab_cc;

    execute immediate
       'select count(*) from dba_tab_partitions where ' ||
       'cellmemory like ''MEMCOMPRESS%'' and ' ||
       'not (tablespace_name in (''SYSTEM'', ''SYSAUX'') ' ||
       'and table_owner like ''SYS'') and table_name ' ||
       'not like ''BIN$%'''
    into num_tab_part_cc;

    -- check if any segments are actually in-memory
    execute immediate
       'select count(*) from gv$im_segments_detail where ' ||
       'segtype=0'
    into num_segs;

    -- check the value of the parameter "inmemory_size" from
    -- all instances
    execute immediate
       'select nvl(max(value),0) from gv$parameter where ' ||
       'name = ''inmemory_size'''
    into inmemory_size_value;

    --Summary
    feature_usage :=
        ' In-Memory Column Store Feature Usage: ' ||
                'In-Memory Column Store Tables: ' ||
                  to_char(num_tab) ||
        ', ' || 'In-Memory Column Store Table Partitions: ' ||
                  to_char(num_tab_part) ||
        ', ' || 'In-Memory Column Store Table Subpartitions: ' ||
                  to_char(num_tab_subpart) ||
        ', ' || 'Total In-Memory Column Store Segments Populated: ' ||
                  to_char(num_segs) ||
        ', ' || 'Cellcache Column Store Tables: ' ||
                  to_char(num_tab_cc) ||
        ', ' || 'Cellcache Column Store Table Partitions: ' ||
                  to_char(num_tab_part_cc);

     if (((num_tab + num_tab_part + num_tab_subpart + num_segs > 0)
          AND (inmemory_size_value > 0))
    OR  (num_tab_cc + num_tab_part_cc > 0))
        then
      feature_boolean := 1;
      feature_info := to_clob(feature_usage);
    else
      feature_boolean := 0;
      feature_info := to_clob('In-Memory Column Store Not Detected');
    end if;
END;
/

