create type create_table_cost_colinfo is object
  (
                         col_type varchar(200),
                         col_size number
  )
/

