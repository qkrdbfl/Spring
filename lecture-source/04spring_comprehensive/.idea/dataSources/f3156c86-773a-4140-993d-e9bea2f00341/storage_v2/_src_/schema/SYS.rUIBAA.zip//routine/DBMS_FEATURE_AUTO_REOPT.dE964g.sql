create PROCEDURE dbms_feature_auto_reopt
  (feature_boolean    OUT  NUMBER,
   aux_count          OUT  NUMBER,
   feature_info       OUT  CLOB)
AS
  NEW_LINE      CONSTANT  VARCHAR2(8) := '
';

  reporting_param         VARCHAR2(10);
  use_feedback_param      VARCHAR2(10);
  num_all_queries         NUMBER;   -- number of queries
  num_reopt_queries       NUMBER;   -- number of reoptimizable queries
  tmp_buf                 VARCHAR2(32767);

BEGIN
  dbms_lob.createtemporary(feature_info, TRUE);

  select ksppstvl
  into reporting_param
  from x$ksppi x, x$ksppcv y where (x.indx = y.indx) and
  ksppinm = 'optimizer_adaptive_reporting_only';

  select ksppstvl
  into use_feedback_param
  from x$ksppi x, x$ksppcv y where (x.indx = y.indx) and
  ksppinm = '_optimizer_use_feedback';

  if (reporting_param = 'FALSE' AND use_feedback_param = 'TRUE') then
    feature_boolean := 1;
  else
    feature_boolean := 0;
  end if;

  -- Find # of sqls in v$sql
  select count(*)
  into   num_all_queries
  from   v$sql vs, v$sqlcommand vsc
  where vs.command_type = vsc.command_type and
  vsc.command_name in ('INSERT', 'SELECT', 'UPDATE', 'DELETE', 'UPSERT');

  -- Find # of sqls which are reoptimizable
  select count(*)
  into   num_reopt_queries
  from   v$sql vs, v$sqlcommand vsc
  where vs.command_type = vsc.command_type and vs.is_reoptimizable = 'Y'
  and vsc.command_name in ('INSERT', 'SELECT', 'UPDATE', 'DELETE', 'UPSERT');

  tmp_buf := 'Total number of queries: ' || num_all_queries ||
             NEW_LINE ;

  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  tmp_buf := 'Number of reoptimizable queries: ' || num_reopt_queries ||
             NEW_LINE ;

  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  tmp_buf := 'Percentage of reoptimizable queries: ' ||
             100*num_reopt_queries/num_all_queries ||
             NEW_LINE ;

  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

END dbms_feature_auto_reopt;
/

