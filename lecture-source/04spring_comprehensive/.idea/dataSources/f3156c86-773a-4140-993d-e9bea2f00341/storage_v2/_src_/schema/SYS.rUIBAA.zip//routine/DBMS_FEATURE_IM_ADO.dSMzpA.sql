create procedure DBMS_FEATURE_IM_ADO
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage         varchar2(1000);
    num_im_ado_pol        number := 0;
    num_obj_pol           number := 0;
    im_size               number := 0;

begin
    -- initialize
    feature_boolean := 0;
    aux_count       := 0;

    -- check for ILM usage by counting policies in ILM dictionary
    select count(*) into num_im_ado_pol
      from sys.ilmpolicy$
     where pol_subtype = 1;

    if (num_im_ado_pol > 0) then

     -- check the value of the parameter "inmemory_size" from
     -- all instances
     execute immediate
        'select nvl(max(value),0) from gv$parameter where ' ||
        'name = ''inmemory_size'''
      into im_size;

     if (im_size > 0) then
        feature_boolean := 1;

        select count(*) into num_obj_pol
          from sys.ilmobj$
         where policy# in (select policy# from sys.ilmpolicy$
                          where pol_subtype = 1);

        feature_usage   :=
                'Number of IM ADO Policies: ' || to_char(num_im_ado_pol) ||
        ', ' || 'Number of Objects Affected: ' || to_char(num_obj_pol);
        feature_info    := to_clob(feature_usage);

     end if;
   end if;
end;
/

