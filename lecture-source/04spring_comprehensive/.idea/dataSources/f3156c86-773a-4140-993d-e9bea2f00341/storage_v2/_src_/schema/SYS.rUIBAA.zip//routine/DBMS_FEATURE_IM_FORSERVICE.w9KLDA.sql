create procedure DBMS_FEATURE_IM_FORSERVICE(
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
AS
    feature_usage               varchar2(1000);
    num_tablespaces             number;
    num_tab                     number;
    num_tab_part                number;
    num_tab_subpart             number;
BEGIN
    feature_boolean             := 0;
    aux_count                   := 0;
    num_tablespaces             := 0;
    num_tab                     := 0;
    num_tab_part                := 0;
    num_tab_subpart             := 0;

    execute immediate
        'select count(*) from dba_tables where ' ||
        'inmemory_service = ''USER_DEFINED'''
    into num_tab;

    execute immediate
        'select count(*) from dba_tab_partitions where ' ||
        'inmemory_service = ''USER_DEFINED'''
    into num_tab_part;

    execute immediate
        'select count(*) from dba_tab_subpartitions where ' ||
        'inmemory_service = ''USER_DEFINED'''
    into num_tab_subpart;

    execute immediate
        'select count(*) from dba_tablespaces where ' ||
        'def_inmemory_service = ''USER_DEFINED'''
    into num_tablespaces;

    --Summary
    feature_usage :=
        ' In-Memory For Service Feature Usage: ' ||
                'In-Memory USER_DEFINED For Service Tables: ' ||
                  to_char(num_tab) ||
        ', ' || 'In-Memory USER_DEFINED For Service Table Partitions: ' ||
                  to_char(num_tab_part) ||
        ', ' || 'In-Memory USER_DEFINED For Service Table Subpartitions: ' ||
                  to_char(num_tab_subpart) ||
        ', ' || 'In-Memory USER_DEFINED For Service Tablespaces: ' ||
                  to_char(num_tablespaces);

     if ((num_tab > 0) OR (num_tab_part > 0) OR (num_tab_subpart > 0) OR
         (num_tablespaces > 0)) then
      feature_boolean := 1;
      feature_info := to_clob(feature_usage);
     end if;
END;
/

