create TYPE     dbms_aw$_dimension_source_t AS OBJECT
   (dimname     VARCHAR2(300),
    columnname  VARCHAR2(300),
    sourcevalue VARCHAR2(32767),
    dimtype     NUMBER(3,0),
    hiercols    dbms_aw$_columnlist_t,
    partby      NUMBER(10,0))
/

