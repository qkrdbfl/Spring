create TYPE CREC FORCE AS OBJECT(
    name    dbms_id,                    -- bug # 19366477 - changed from
    type    number,                     -- c.type#
    sel     dbms_quoted_id,             -- select list item
    def     varchar2(32767),            -- c.default$
    alias   varchar2(30),               -- alias (null if unnecessary)
    nlable  number,                     -- c.null$
    unq     number,                     -- unique if not null
    ucol    number,                     -- c.col#
    icol    number,                     -- c.intcol#
    fixlen  number,                     -- fixed column length
    maxlen  number,                     -- max column length
    hind    integer,                    -- index into first ColHistTab entry
    pfreq   number,                     -- avg frequency based on previously
    gather  integer,                    -- flags indicating basic stats
    hgath   integer,                    -- flags indicating histograms
    bktnum  integer,                    -- # buckets for this histogram
    hreq    integer,                    -- histogram collection required
    freq    integer,                    -- frequency histogram if true
    aclonly integer,                    -- 3620168: only get avg col len
    snnv    number,                     -- sample number of non-null values
    sndv    number,                     -- sample number of distinct values
    snnvdv  number,                     -- sample non-null for dv
    slsv    number,                     -- linearly scalable values in sample
    nnv     number,                     -- number of non-null values
    nv      number,                     -- number of null values
    ndv     number,                     -- number of distinct values
    acl     number,                      -- average column length
    ccnt    number,                     -- > 0 if have histograms
    dens    number,                     -- density
    minval  raw(64),                    -- minimum
    maxval  raw(64),                    -- maximum
    nmin    number,                     -- normalized minimum
    nmax    number,                     -- normalized maximum
    dmin    varchar2(240),              -- 'dump'ed minimum
    dmax    varchar2(240)               -- 'dump'ed maximum
  );
/

