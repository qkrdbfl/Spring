create TYPE adr_log_msg_ecid_t FORCE AS OBJECT
(
  id         VARCHAR2(100),                          /* execution context id */
  rid        VARCHAR2(100)                  /* execution context sequence id */
);
/

