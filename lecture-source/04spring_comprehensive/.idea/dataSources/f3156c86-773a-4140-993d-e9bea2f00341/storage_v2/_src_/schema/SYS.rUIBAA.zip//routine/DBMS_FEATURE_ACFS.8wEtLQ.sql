create PROCEDURE dbms_feature_acfs
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
  numfs    NUMBER;                            -- # of file systems
BEGIN
  /* Query to detect if ACFS drivers are loaded */
  select sys_context('SYS_CLUSTER_PROPERTIES','ACFS_SUPPORTED')
         into is_used from dual;

  /* Query to retrieve the number of file systems across the cluster */
  select count(*) into numfs from gv$asm_filesystem;

   -- compose the CLOB
   feature_info := ':num_filesystems:'||numfs;
END;
/

