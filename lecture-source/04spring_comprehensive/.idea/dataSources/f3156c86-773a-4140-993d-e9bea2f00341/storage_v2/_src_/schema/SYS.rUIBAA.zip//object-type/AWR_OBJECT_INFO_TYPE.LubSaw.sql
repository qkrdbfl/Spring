create type AWR_OBJECT_INFO_TYPE
 as object (
             owner_name        VARCHAR2(128)
           , object_name       VARCHAR2(256)
           , subobject_name    VARCHAR2(256)
           , tablespace_name   VARCHAR2(64)
           , object_type       VARCHAR2(64)
           , partition_type    VARCHAR2(64)
           , index_type        VARCHAR2(64)
           , base_object_name  VARCHAR2(128)
           , base_object_owner VARCHAR2(128)
           , base_object_id    NUMBER
)
/

