create package     CDBView_internal
  accessible by (package sys.CDBView) as

  /* In a separate package to permit PRAGMA RR. */
  PROCEDURE long2varchar2_i (stmt   IN VARCHAR2,
                             rowid  IN ROWID,
                             rowval IN OUT VARCHAR2
                            );
  PRAGMA RESTRICT_REFERENCES (long2varchar2_i, WNDS, RNPS, WNPS);

end;
/

