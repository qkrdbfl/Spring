create type aq$_jms_message_property
                                                                      
as object
(
   priority          int,
   delay             int,
   expiration        int,
   correlation       varchar2(128),
   attempts          int,
   recipient_list    sys.aq$_recipients,
   exception_queue   varchar2(128),
   enqueue_time      date,
   state             int,
   sender_id         sys.aq$_agent,
   original_msgid    raw(16),
   signature         sys.aq$_sig_prop,
   transaction_group varchar2(30)
);
/

