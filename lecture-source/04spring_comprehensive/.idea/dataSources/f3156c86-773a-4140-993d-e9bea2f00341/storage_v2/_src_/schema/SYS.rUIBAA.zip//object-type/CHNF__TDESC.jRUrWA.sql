create type chnf$_tdesc as object(
   opflags number,
   table_name varchar2(64),
   numrows number,
   row_desc_array chnf$_rdesc_array)
 alter type chnf$_tdesc modify attribute table_name varchar2(257)
  cascade
/

