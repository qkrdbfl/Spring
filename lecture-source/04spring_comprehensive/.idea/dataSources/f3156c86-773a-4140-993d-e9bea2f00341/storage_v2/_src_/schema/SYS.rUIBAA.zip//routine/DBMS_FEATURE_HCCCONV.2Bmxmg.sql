create PROCEDURE DBMS_FEATURE_HCCCONV
      ( feature_boolean  OUT  NUMBER,
        aux_count        OUT  NUMBER,
        feature_info     OUT  CLOB)
 AS
   feature_count NUMBER;
   feature_usage varchar2(100);
 BEGIN
   -- initialize
   feature_info  := NULL;
   feature_count := 0;

   execute immediate 'select sum(value) from v$sysstat where name ' ||
   'like ''HCC load conventional bytes compressed''' into feature_count;

   feature_usage :=
    'Hybrid Columnar Compressed Conventional: ' || to_char(feature_count);
   feature_info  := to_clob(feature_usage);

   if (feature_count > 0) then
     feature_boolean := 1;
   else
     feature_boolean := 0;
   end if;
   aux_count := feature_count;
 END;
/

