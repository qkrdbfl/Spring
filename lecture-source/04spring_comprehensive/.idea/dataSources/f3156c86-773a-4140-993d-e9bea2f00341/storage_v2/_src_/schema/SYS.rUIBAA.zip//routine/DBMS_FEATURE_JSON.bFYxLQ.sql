create procedure DBMS_FEATURE_JSON
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB )
AS
  num_json_cols         number := 0;
  num_clob_cols         number := 0;
  num_blob_cols         number := 0;
  num_raw_cols          number := 0;
  num_varchar2_cols     number := 0;
  num_json_view         number := 0;
  num_jv_view           number := 0;
  num_je_view           number := 0;
  num_jq_view           number := 0;
  num_jt_view           number := 0;
  num_dg_view           number := 0;
  num_min_rows          number := 0;
  num_max_rows          number := 0;
  num_avg_rows          number := 0;
  num_jv_fidx           number := 0;
  num_je_fidx           number := 0;
  num_jq_fidx           number := 0;
  num_json_cidx         number := 0;
  num_bson_cidx         number := 0;
  maxsize_jsoncol       number := 0;
  avgsize_jsoncol       number := 0;
  num_dataguides        number := 0;
  num_collections       number := 0;
  num_imcu_json         number := 0;
  num_imeu_json         number := 0;
  num_json_imc_enabled  number := 0;
  num_i_rows            number := 0;
  num_sn_rows           number := 0;
  num_dg_rows           number := 0;
  stmt                  varchar2(1000);
  table_not_found       EXCEPTION;
  PRAGMA exception_init(table_not_found, -942);
  CURSOR expr_cur IS
    SELECT COLUMN_EXPRESSION
    FROM DBA_IND_EXPRESSIONS;
  expr   expr_cur%ROWTYPE;
  c         clob;
  TYPE      CurTyp IS REF CURSOR;
  cur       CurTyp;
  idxname1   dbms_id;
  uname1     dbms_id;
  idxname2   dbms_quoted_id;
  uname2     dbms_quoted_id;
BEGIN
  -- initialize
  feature_boolean := 0;
  aux_count := 0;
  feature_info := '{ "version":1, ';

  /* get the number of json cols from dba_json_columns */
  execute immediate 'select count(1) from dba_json_columns
                     where owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_json_cols;

  /* Number of CLOB columns */
  execute immediate 'select count(1) from dba_json_columns
                     where data_type = ''CLOB'' and owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_clob_cols;

  /* Number of BLOB columns */
  execute immediate 'select count(1) from dba_json_columns
                     where data_type = ''BLOB'' and owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_blob_cols;

  /* Number of RAW columns */
  execute immediate 'select count(1) from dba_json_columns
                     where data_type = ''RAW'' and owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_raw_cols;

  /* Number of varchar columns */
  execute immediate 'select count(1) from dba_json_columns
                     where data_type = ''VARCHAR2'' and owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_varchar2_cols;

  /* Write Storage stats into clob */
  dbms_lob.append(feature_info, to_clob ('"jsonColumns": {' ||
                  '"total":' || to_char(num_json_cols) || ' , ' ||
                  '"varchar2":' || to_char(num_varchar2_cols) || ' , ' ||
                  '"clob":' || to_char(num_clob_cols) || ' , ' ||
                  '"blob":' || to_char(num_blob_cols) || ' , ' ||
                  '"raw":'  || to_char(num_raw_cols)  || ' }, '));

  /* Get the min, max and avg size of the JSON tables */
  execute immediate 'select max(num_rows) from dba_tables where
                     table_name in (select table_name
                     from dba_json_columns where owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y''))'
  into num_max_rows;

  execute immediate 'select min(num_rows) from dba_tables where
                     table_name in (select table_name
                     from dba_json_columns where owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y''))'
  into num_min_rows;

  execute immediate 'select avg(num_rows) from dba_tables where
                     table_name in (select table_name
                     from dba_json_columns where owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y''))'
  into num_avg_rows;

  if num_max_rows is null then
    num_max_rows := 0;
  end if;

  if num_min_rows is null then
    num_min_rows := 0;
  end if;

  if num_avg_rows is null then
    num_avg_rows := 0;
  end if;

  /* Write row count stats into clob */
  dbms_lob.append(feature_info, to_clob ('"rowCount": {' ||
                  '"maxCount":' || to_char(num_max_rows) || ' , ' ||
                  '"minCount":' || to_char(num_min_rows) || ' , ' ||
                  '"avgCount":' || to_char(num_avg_rows) || ' }, '));

  /* Get size of JSON column */
  /* Average length in bytes */
  execute immediate 'select nvl(avg(avg_col_len),0) from dba_tab_columns t,
                     dba_json_columns j where t.owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')
                     and t.table_name = j.table_name
                     and t.column_name = j.column_name'
  into avgsize_jsoncol;

  /* Max length in chars */
  execute immediate 'select nvl(max(char_length),0) from dba_tab_columns t,
                     dba_json_columns j where t.owner not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')
                     and t.table_name = j.table_name
                     and t.column_name = j.column_name'
  into maxsize_jsoncol;

  /* Write row size stats into clob */
  dbms_lob.append(feature_info, to_clob ('"rowSize": {' ||
                  '"avgSizeBytes":' || to_char(avgsize_jsoncol) || ' , ' ||
                  '"maxSizeChars":' || to_char(maxsize_jsoncol) || ' }, '));

  /* IMC related stats */
  /* JSON stored in IMCUs */
  execute immediate 'select count(1) from v$im_col_cu a, sys.col$ b,
                                           dba_json_columns j, obj$ o
                      where a.objd = b.obj# and
                            b.obj# = o.obj# and
                            a.column_number = b.segcol# and
                            b.name = j.column_name and
                            o.name = j.table_name'
  into num_imcu_json;

  /* OSON corresponding to JSON stored in IMEUs */
  execute immediate 'select count(1) from v$im_imecol_cu a, sys.col$ b
                     where a.objd = b.obj# and
                           a.internal_column_number = b.intcol# and
                           b.name like ''SYS_IME_OSON%'''
  into num_imeu_json;

  /* Get number of JSON cols/tables which have just been enabled for IMC */
  execute immediate 'select count(1) from x$kdzcolcl x, dba_json_columns j
                    where x.column_name = j.column_name and
                          x.table_name = j.table_name and
                          x.owner = j.owner'
  into num_json_imc_enabled;

  /* Write row size stats into clob */
  dbms_lob.append(feature_info, to_clob ('"IMCStats": {' ||
                  '"IMCU#":' || to_char(num_imcu_json) || ' , ' ||
                  '"IMEU#":' || to_char(num_imeu_json) || ' , ' ||
                  '"JSONIMC#":' || to_char(num_json_imc_enabled) || ' }, '));

  /* Get the JSON view stats */
  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_VALUE%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_jv_view;

  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_EXISTS%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_je_view;

  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_QUERY%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_jq_view;

  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_TABLE%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_jt_view;

  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_DATAGUIDE%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_dg_view;

  execute immediate 'select count(1) from dba_views where
                     upper(text_vc) like ''%JSON_%'' and owner
                     not in (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_json_view;

  /* Write JSON view stats into clob */
  dbms_lob.append(feature_info, to_clob ('"views": {' ||
                  '"total":' || to_char(num_json_view) || ' , ' ||
                  '"jsonValue":'  || to_char(num_jv_view) || ' , ' ||
                  '"jsonExists":' || to_char(num_je_view) || ' , ' ||
                  '"jsonQuery":'  || to_char(num_jq_view) || ' , ' ||
                  '"jsonTable":'  || to_char(num_jt_view) || ' , ' ||
                  '"jsonDataGuide":'  || to_char(num_dg_view) || ' }, '));

  /* Indexes */

  /* Get JSON Functional Index stats */
  OPEN expr_cur;
  LOOP
      FETCH expr_cur INTO expr;
      EXIT WHEN expr_cur%NOTFOUND;
      c := to_clob(expr.COLUMN_EXPRESSION);
      if (upper(c) like '%JSON_VALUE%') then
        num_jv_fidx := num_jv_fidx + 1;
      elsif (upper(c) like '%JSON_EXISTS%') then
        num_je_fidx := num_je_fidx + 1;
      elsif (upper(c) like '%JSON_QUERY%') then
        num_jq_fidx := num_jq_fidx + 1;
      end if;
  END LOOP;
  CLOSE expr_cur;

  /* Write JSON view stats into clob */
  dbms_lob.append(feature_info, to_clob ('"funcIdx": {' ||
                  '"jsonValue":'  || to_char(num_jv_fidx) || ' , ' ||
                  '"jsonExists":' || to_char(num_je_fidx) || ' , ' ||
                  '"jsonQuery":'  || to_char(num_jq_fidx) || ' }, '));


  dbms_lob.append(feature_info, to_clob ('"searchIdxStats": {' ));
  /* Get JSON text indexes stats */
  stmt:= 'select i.idx_name, u.username
          from ctxsys.dr$index i, all_users u
          where i.idx_id in ( select ixv_idx_id
                              from ctxsys.dr$index_value
                              where IXV_OAT_ID = 50817) and
                i.idx_owner# = u.user_id and u.username not in
                                 (select distinct username
                                  from all_users
                                  where oracle_maintained = ''Y'')';
  open cur for stmt;
    LOOP
      fetch cur into idxname1, uname1;
      exit when cur%notfound;

      idxname2 := DBMS_ASSERT.ENQUOTE_NAME(idxname1, false);
      uname2   := DBMS_ASSERT.ENQUOTE_NAME(uname1, false);

      num_json_cidx := num_json_cidx + 1;
    begin
      stmt := 'select count(*) from ' || uname2 || '.' ||
              dbms_assert.enquote_name('DR$'||idxname1||'$I', FALSE);
      execute immediate stmt into num_i_rows;
    exception
      when table_not_found then
        null;
    end;

    begin
      stmt := 'select count(*) from ' || uname2 || '.' ||
              dbms_assert.enquote_name('DR$'||idxname1||'$SN', FALSE);
      execute immediate stmt into num_sn_rows;
    exception
      when table_not_found then
        null;
    end;

    begin
      stmt := 'select count(*) from ' || uname2 || '.' ||
              dbms_assert.enquote_name('DR$'||idxname1||'$DG', FALSE);
      execute immediate stmt into num_dg_rows;
    exception
      when table_not_found then
        null;
    end;

    dbms_lob.append(feature_info, to_clob ('"Index-Stats": {' ||
                  '"indexName":' || idxname2 || ' , ' ||
                  '"num$IRows":' || to_char(num_i_rows) || ' , ' ||
                  '"num$SNRows":' || to_char(num_sn_rows) || ' , ' ||
                  '"num$DGRows":' || to_char(num_dg_rows)  || ' }, '));
  END LOOP;
  dbms_lob.append(feature_info, to_clob ('},'));

  begin
  execute immediate 'select count(1) from ctxsys.dr$index i, sys.user$ u
                     where i.idx_id in (select ixv_idx_id from
                     ctxsys.dr$index_value where IXV_OAT_ID = 50819) and
                     i.idx_owner# = u.user# and u.name not in
                     (select distinct username from all_users
                      where oracle_maintained = ''Y'')'
  into num_bson_cidx;
  exception
    when OTHERS then
       num_bson_cidx := 0;
  end;

  /* Write JSON Search index stats into clob */
  dbms_lob.append(feature_info, to_clob ('"searchIdx": {' ||
                  '"jsonSearchIdx":' || to_char(num_json_cidx) || ' , ' ||
                  '"bsonSearchIdx":' || to_char(num_bson_cidx)  || ' }, '));

  /* Get the JSON dataguide stats*/
  execute immediate 'select count(1) from ALL_JSON_DATAGUIDES'
  into num_dataguides;

  /* Write JSON dataguide stats into clob */
  dbms_lob.append(feature_info, to_clob ('"dataguideStats": {' ||
                  '"numDataguide":' || to_char(num_dataguides) || ' }, '));

  /* Get the SODA JSON stats*/
  execute immediate 'select count(1) from XDB.JSON$COLLECTION_METADATA'
  into num_collections;

  /* Write SODA JSON stats into clob */
  dbms_lob.append(feature_info, to_clob ('"sodaStats": {' ||
                  '"numCollections":' || to_char(num_collections) || ' } } '));

  /* set feature_boolean if reqd */
  IF num_json_cols > 0 THEN
    feature_boolean := 1;
  END IF;
END;
/

