create FUNCTION aq$_get_subscribers (
  queue_schema   IN  VARCHAR2,
  queue_name     IN  VARCHAR2,
  queue_table    IN  VARCHAR2,
  deq_user       IN  VARCHAR2,
  queue_id       IN  BINARY_INTEGER,
  qtab_flags     IN  BINARY_INTEGER) RETURN sys.aq$_subscriber_t PIPELINED IS

  sub80          aq$_subscribers;
  sel_txt        VARCHAR2(1000);
  type rt is	 REF CURSOR;
  sqlrc		 rt;		  	 	-- ref cursor for sql statement
  sub_name       VARCHAR2(512);
  sub_addr       VARCHAR2(1024);
  sub_proto      NUMBER;
  sub_trans      VARCHAR2(261);
  sub_trans_sch  VARCHAR2(128);
  sub_trans_nm   VARCHAR2(128);
  sub_type       NUMBER;
  sub_rule       VARCHAR2(128); /*bug 648822: add rule_name for the subscriber*/
  sub_id         NUMBER;
  sub_bpos       NUMBER;
BEGIN
  IF bitand(qtab_flags, 8) = 0 and bitand(qtab_flags, 67108864) = 0 THEN
    -- 8.0 style queue, return all subscribers in aq$_queues
    select subscribers INTO sub80 FROM system.aq$_queues
    where  eventid = queue_id;

    IF sub80 IS NOT NULL and sub80.count > 0 THEN
      FOR i IN sub80.first .. sub80.last LOOP
       PIPE ROW (aq$_subscriber(sub80(i).name, sub80(i).address,
                 sub80(i).protocol, null, 65, null, null, null));
      END LOOP;
    END  IF;
  ElSIF bitand(qtab_flags, 4096) = 4096 and deq_user IS NOT NULL THEN
    -- 8.1 style secure queue, join with agent mapping table
    sel_txt := 'select qs.name, qs.address, qs.protocol, qs.trans_name, '
               || ' qs.subscriber_type,  qs.rule_name from '
               || 'dba_aq_agent_privs dp, '
               || dbms_assert.enquote_name('"'||queue_schema||'"') || '.'
               || dbms_assert.enquote_name('"AQ$_' || queue_table || '_S"')
               || ' qs where dp.db_username = :1 and ' ||
               'dp.agent_name = qs.name and bitand(qs.subscriber_type, 1)=1'
               || ' and qs.queue_name = :2';
    OPEN sqlrc FOR sel_txt using deq_user, queue_name;
    LOOP
      FETCH sqlrc INTO sub_name, sub_addr, sub_proto,sub_trans, sub_type, sub_rule;
      EXIT WHEN sqlrc%NOTFOUND;
      PIPE ROW (aq$_subscriber(sub_name, sub_addr, sub_proto, sub_trans,
                               sub_type, sub_rule, null, null));
    END LOOP;

  ELSIF bitand(qtab_flags, 67108864) = 67108864 THEN
    -- 12c style sharded queue
    sel_txt := 'select name, address, protocol, trans_owner,' ||
               'trans_name , subscriber_type, ' ||
               'rule_name, subscriber_id, pos_bitmap ' ||
               'from SYS.AQ$_DURABLE_SUBS s ' ||
               'WHERE queue_id = :1 and '||
               ' parent_id is NULL and ' ||
               'bitand(s.subscriber_type, 1)=1';
    OPEN sqlrc FOR sel_txt using queue_id;
    LOOP
      FETCH sqlrc INTO sub_name, sub_addr, sub_proto, sub_trans_sch,
                       sub_trans_nm,  sub_type, sub_rule, sub_id, sub_bpos;
      if sub_trans_sch is not null then
        sub_trans := dbms_assert.enquote_name(sub_trans_sch, FALSE) ||'.' ||
                     dbms_assert.enquote_name(sub_trans_nm, FALSE);
      end if;
      EXIT WHEN sqlrc%NOTFOUND;
      PIPE ROW (aq$_subscriber(sub_name, sub_addr, sub_proto,
                               sub_trans, sub_type,
                               sub_rule, sub_id, sub_bpos));
    END LOOP;
  ELSE
    -- 8.1 style normal queue, return all subscribers
    sel_txt := 'select name, address, protocol, trans_name, ' ||
               'subscriber_type, rule_name from ' ||
               dbms_assert.enquote_name('"'||queue_schema||'"') || '.' ||
               dbms_assert.enquote_name('"AQ$_' || queue_table || '_S"') ||
               ' where ' ||
               'bitand(subscriber_type, 1)=1 and queue_name = :1';
    OPEN sqlrc FOR sel_txt using queue_name;
    LOOP
      FETCH sqlrc INTO sub_name, sub_addr, sub_proto, sub_trans, sub_type, sub_rule;
      EXIT WHEN sqlrc%NOTFOUND;
      PIPE ROW (aq$_subscriber(sub_name, sub_addr, sub_proto, sub_trans,
                               sub_type, sub_rule, null, null));
    END LOOP;
  END IF;
  RETURN;
END;
/

