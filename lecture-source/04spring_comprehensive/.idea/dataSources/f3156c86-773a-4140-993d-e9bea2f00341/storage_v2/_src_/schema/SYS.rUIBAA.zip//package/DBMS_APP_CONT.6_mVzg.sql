create PACKAGE dbms_app_cont AS

  ------------
  --  OVERVIEW
  --
  --  This package allows an application to determine the outcome of
  --  a transaction.

  ------------
  --  SECURITY
  --
  --  The execute privilage of the package is granted to DBA role only.

  ----------------
  --  INSTALLATION
  --
  --  This package should be installed under SYS schema.
  --
  --  SQL> @dbmsappcont
  --

  ----------------------------
  --  CONSTANTS
  --
  NOT_COMMITTED CONSTANT NUMBER(1)        := 1;
  COMMITTED CONSTANT NUMBER(1)            := 2;


  -------------------------
  --  ERRORS AND EXCEPTIONS
  --
  --  When adding errors remember to add a corresponding exception below.

  err_server_ahead       CONSTANT NUMBER := -14950;
  err_client_ahead       CONSTANT NUMBER := -14951;
  err_general_failure    CONSTANT NUMBER := -14952;

  exc_server_ahead       EXCEPTION;
  PRAGMA EXCEPTION_INIT(exc_server_ahead,    -14950);
  exc_client_ahead       EXCEPTION;
  PRAGMA EXCEPTION_INIT(exc_client_ahead,    -14951);
  exc_general_failure    EXCEPTION;
  PRAGMA EXCEPTION_INIT(exc_general_failure, -14952);


  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --
  PROCEDURE get_ltxid_outcome(client_ltxid        IN  RAW,
                              committed           OUT BOOLEAN,
                              user_call_completed OUT BOOLEAN);
  --  Forces the outcome of a transaction. If the transaction has not
  --  been commited yet, a fake transaction is committed. Otherwise the
  --  the state of the transaction is returned.
  --
  --  Input parameter(s):
  --    client_ltxid
  --      LTXID from the client driver.
  --
  --  Output parameter(s):
  --    committed           - Transaction has been committed
  --    user_call_completed - User call that committed the transaction has
  --                          been completed.
  --
  --  Exceptions:
  --      - SERVER_AHEAD, the server is ahead, so the transaction is an
  --                      old transaction and must have already been
  --                      committed.
  --      - CLIENT_AHEAD, the client is ahead of the server. This can only
  --                      happen if the server has been flashbacked or the
  --                      ltxid is corrupted. In any way, the outcome
  --                      cannot be determined.
  --      - ERROR, the outcome cannot be determined. During processing an
  --               error happened.
  --    error
  --      Error code raised during the execution of force_outcome.
  --
END dbms_app_cont;
/

