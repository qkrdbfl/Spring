create type AWRBL_METRIC_TYPE force
  as object (baseline_name       varchar2(128)
            ,dbid                number
            ,instance_number     number
            ,beg_time            timestamp(3)
            ,end_time            timestamp(3)
            ,metric_name         varchar2(64)
            ,metric_unit         varchar2(64)
            ,num_interval        number
            ,interval_size       number
            ,average             number
            ,minimum             number
            ,maximum             number)
/

