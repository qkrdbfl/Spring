create PROCEDURE dbms_feature_flex_asm
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
   flxasmstat         VARCHAR2(30);
   numfailovr         VARCHAR2(30);
BEGIN
  select sys_context('SYS_CLUSTER_PROPERTIES', 'FLEXASM_STATE')
         into flxasmstat from dual;

  if (flxasmstat = 'FLEXASM_ENABLED') then
    is_used := 1;
  else
    is_used := 0;
  end if;

  if (is_used >= 1) then
    select sys_context('SYS_CLUSTER_PROPERTIES', 'FLEXASM_STATE_HW')
           into numfailovr from dual;

    -- compose the CLOB
    feature_info := ':num_failovers:'||numfailovr;
  end if;

END;
/

