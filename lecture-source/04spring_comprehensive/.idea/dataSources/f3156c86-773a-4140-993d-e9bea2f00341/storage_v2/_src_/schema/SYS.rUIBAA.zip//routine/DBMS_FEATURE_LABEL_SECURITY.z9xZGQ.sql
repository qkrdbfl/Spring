create PROCEDURE dbms_feature_label_security
     ( feature_boolean  OUT NUMBER,
       aux_count        OUT NUMBER,
       feature_info     OUT CLOB)
AS
begin
  -- execute immediate as lbacsys is not installed yet
  execute immediate 'begin lbacsys.feature_usage(:1,:2,:3); end;'
                     USING OUT feature_boolean,
                           OUT aux_count,
                           OUT feature_info;

  EXCEPTION WHEN OTHERS THEN
    null;

end dbms_feature_label_security;
/

