create procedure DBMS_FEATURE_HEATMAP
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage   varchar2(300);
    num_tbs         number := 0;
    num_seg         number := 0;
    num_blocks      number := 0;
begin
    -- initialize
    feature_boolean := 0;
    aux_count       := 0;
    feature_info    := to_clob('Heat Map feature is not used');

/* Note:
 * Bug 27119186:  For 18.1 AIM feature, access tracking for IM segments may be
 * on, even when heat_map is turned off. Filter out rows that were tracked when
 * heat_map was off using the predicate 'bitand(flag,1) = 0'
 *
 * However, block heat map is not tracked when heat_map is turned off.
 * So no special processing is needed for the query on x$ktfsimstat;
 */


    -- Distinct tablespaces tracked

    execute immediate 'select count(distinct(ts#)) from heat_map_stat$ ' ||
                      ' where obj# <> -1 and bitand(flag,1) = 0'
       into num_tbs;


    -- Distinct segments tracked
    execute immediate 'select count(*) from ' ||
                ' (select distinct obj#, dataobj#, ts# from heat_map_stat$ ' ||
                  ' where obj# <> -1 and bitand(flag,1) = 0)'
       into num_seg;

    -- Blocks tracked in memory
    execute immediate 'select count(*) from x$ktfsimstat' into num_blocks;

    if num_tbs > 0 OR num_seg > 0 OR num_blocks > 0 then

      feature_boolean := 1;
      feature_usage   :=
                'Number of Tablespaces Tracked: ' || to_char(num_tbs) ||
        ', ' || ' Number of Segments Tracked: ' || to_char(num_seg) ||
        ', ' || ' Number of Blocks Tracked in Memory: ' || to_char(num_blocks);
      feature_info    := to_clob(feature_usage);

    end if;

end;
/

