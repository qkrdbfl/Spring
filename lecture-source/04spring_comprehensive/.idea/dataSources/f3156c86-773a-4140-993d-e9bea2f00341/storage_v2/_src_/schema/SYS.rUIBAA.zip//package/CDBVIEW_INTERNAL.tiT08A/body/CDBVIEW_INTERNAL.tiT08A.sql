create package body     CDBView_internal as

  PROCEDURE long2varchar2_i (stmt   IN VARCHAR2,
                             rowid  IN ROWID,
                             rowval IN OUT VARCHAR2
                            ) IS
    EXTERNAL
    NAME "kpdbLong2Varchar2"
    LANGUAGE C
    LIBRARY DBMS_PDB_LIB
    PARAMETERS (stmt   OCIString,  stmt   indicator sb4,
                rowid  OCIString,  rowid  indicator sb4,
                rowval OCIString,  rowval indicator sb4,
                rowval length sb4, rowval maxlen sb4
               );

end;
/

