create type dbms_dbfs_hs_item_t
    authid definer
as object (
    storename  varchar2(ORA_MAX_NAME_LEN),
    storeowner varchar2(ORA_MAX_NAME_LEN),
    path        varchar2(1024),
    contentfilename   varchar2(1024)
);
/

