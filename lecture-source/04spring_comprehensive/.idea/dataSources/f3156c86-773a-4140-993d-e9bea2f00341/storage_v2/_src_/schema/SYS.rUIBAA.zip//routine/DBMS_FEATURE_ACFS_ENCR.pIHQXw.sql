create PROCEDURE dbms_feature_acfs_encr
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
BEGIN
  /* Query to detect if there is at least one acfs file system
   * with encryption enabled. */
  select count(*) into is_used from V$ASM_ACFS_ENCRYPTION_INFO
         where set_status like 'YES' and
         enabled_status like 'ENABLED';
END;
/

