create package dbms_dbfs_content_admin
    authid definer
as



    /*
     * Administrative and query APIs:
     *
     * (Administrative) clients and store providers are expected to
     * register stores with the DBFS API. Additionally, administrative
     * clients are expected to mount stores into the toplevel namespace
     * of their choice.
     *
     * The registration/unregistration of a store is separated from the
     * mount/unmount of a store since it is possible for the same store
     * to be mounted multiple times at different mount-points (and this
     * is under client control).
     *
     *
     * The administrative methods in "dbms_dbfs_content" are merely
     * wrappers that delegate to the matching methods in
     * "dbms_dbfs_content_admin". Clients can use the methods in either
     * package to perform administrative operations.
     *
     */



    /*
     * Register a new store "store_name" backed by provider
     * "provider_name" that uses "provider_package" as the store
     * provider (conforming to the "dbms_dbfs_content_spi" package
     * signature).
     *
     * This method is to be used primarily by store providers after they
     * have created a new store.
     *
     * Store names must be unique.
     *
     */

    procedure   registerStore(
        store_name          in      varchar2,
        provider_name       in      varchar2,
        provider_package    in      varchar2);

/* registerStore_log: INTERNAL USE ONLY */
    procedure   registerStore_log(
        store_name          in      varchar2,
        provider_name       in      varchar2,
        provider_package    in      varchar2,
        suid                in      varchar2,
        ctime               in      timestamp);
            pragma  supplemental_log_data(
                        registerStore_log,
                        AUTO);



    /*
     * Unregister a previously registered store (invalidating all
     * mount-points associated with it).
     *
     * Once unregistered all access to the store (and its mount-points)
     * are not guaranteed to work (although CR may provide a temporary
     * illusion of continued access).
     *
     *
     * If the "ignore_unknown" argument is "true", attempts to
     * unregister unknown stores will not raise an exception.
     *
     * If the "store_owner" argument is specified, it implies the
     * attempt to cleanup ContentAPI orphans of non-existent schemas.
     *
     */

    procedure   unregisterStore(
        store_name          in      varchar2,
        ignore_unknown      in      boolean         default false,
        store_owner         in      varchar2        default null);

/* unregisterStore_log: INTERNAL USE ONLY */
    procedure   unregisterStore_log(
        store_name          in      varchar2,
        ignore_unknown      in      boolean,
        suid                in      varchar2,
        ctime               in      timestamp);
            pragma  supplemental_log_data(
                        unregisterStore_log,
                        AUTO);



    /*
     * Mount a registered store "store_name" and bind it to the
     * "store_mount" mount-point.
     *
     * Once mounted, accesses to pathnames of the form
     * "/<store_mount>/xyz..." will be redirected to <store_name> and
     * its store provider.
     *
     *
     * Store mount-points must be unique, and a syntactically valid
     * pathname component (i.e. a "name_t" with no embedded "/").
     *
     *
     * If a mount-point is not specified (i.e. is null), the DBFS API
     * attempts to use the store name itself as the mount-point name
     * (subject to the uniqueness and syntactic constraints).
     *
     *
     * A special empty mount-point is available for singleton stores,
     * i.e. a scenario where the DBFS API manages a single backend
     * store---in such cases, the client can directly deal with full
     * pathnames of the form "/xyz..." since there is no ambiguity in
     * how to redirect these accesses.
     *
     * Singleton mount-points are indicated by the "singleton" boolean
     * argument, and the "store_mount" argument is ignored.
     *
     *
     * The same store can be mounted multiple times, obviously at
     * different mount-points.
     *
     *
     * Mount properties can be used to specify the DBFS API execution
     * environment, i.e. default values of the principal, owner, acl,
     * and asof for a particular mount-point. Mount properties can also
     * be used to specify a read-only store.
     *
     */

    procedure   mountStore(
        store_name          in      varchar2,
        store_mount         in      varchar2        default null,
        singleton           in      boolean         default false,
        principal           in      varchar2        default null,
        owner               in      varchar2        default null,
        acl                 in      varchar2        default null,
        asof                in      timestamp       default null,
        read_only           in      boolean         default false,
        view_name           in      varchar2        default null);

/* mountStore_log: INTERNAL USE ONLY */
    procedure   mountStore_log(
        store_name          in      varchar2,
        store_mount         in      varchar2,
        singleton           in      boolean,
        principal           in      varchar2,
        owner               in      varchar2,
        acl                 in      varchar2,
        asof                in      timestamp,
        read_only           in      boolean,
        view_name           in      varchar2,
        suid                in      varchar2,
        ctime               in      timestamp);
            pragma  supplemental_log_data(
                        mountStore_log,
                        AUTO);



    /*
     * Unmount a previously mounted store, either by name or by mount
     * point.
     *
     * Singleton stores can be unmounted only by store name (since they
     * have no mount-points).
     *
     * Attempting to unmount a store by name will unmount all
     * mount-points associated with the store.
     *
     * Once unmounted all access to the store (or mount-point) are not
     * guaranteed to work (although CR may provide a temporary illusion
     * of continued access).
     *
     *
     * If the "ignore_unknown" argument is "true", attempts to
     * unregister unknown stores/mounts will not raise an exception.
     *
     */

    procedure   unmountStore(
        store_name          in      varchar2        default null,
        store_mount         in      varchar2        default null,
        ignore_unknown      in      boolean         default false);

/* unmountStore_log: INTERNAL USE ONLY */
    procedure   unmountStore_log(
        store_name          in      varchar2,
        store_mount         in      varchar2,
        ignore_unknown      in      boolean,
        suid                in      varchar2,
        ctime               in      timestamp);
            pragma  supplemental_log_data(
                        unmountStore_log,
                        AUTO);



    /*
     * Add/remove DBFS clients registrations.
     *
     *
     * "client_info"s must be globally unique; attempting to add a
     * duplicate "client_info" or attempting to delete a non-existent
     * "client_info" will raise exceptions.
     *
     * It is recommended that the "client_info" be correlatable with the
     * "gv$session.client_info" column---this will allow for tracking
     * active/failed clients, and with any associated cleanup activities
     * (for example, lock cleanup).
     *
     * An optional "client_data" (any arbitrary data) can be specified
     * during registration---it will not be interpreted by DBFS.
     *
     *
     * The registration procedures execute in autonomous transactions.
     * The list table function is intended to be invoked from
     * "dbms_dbfs_content.listClients".
     *
     */

    procedure   registerClient(
        client_info         in      varchar2,
        client_data         in      varchar2        default null);

    procedure   unregisterClient(
        client_info         in      varchar2);

    function    listClients
            return  dbms_dbfs_content.clients_t
                pipelined;



    /*
     * Update operation statistics for a store/mount.
     *
     * Statistics flushes are invoked by the DBFS API operations, and
     * update the common metadata tables in a secure manner.
     *
     */

    procedure   updateStats(
        store_name          in      varchar2,
        store_mount         in      varchar2,
        op                  in      integer,
        cnt                 in      integer,
        wt                  in      integer,
        ct                  in      integer);



    /*
     * Utility function: check SPI.
     *
     *
     * Given the name of a putative "dbms_dbfs_content_spi" conforming
     * package, attempt to check that the package really does implement
     * all of the provider methods (with the proper signatures), and
     * report on the conformance.
     *
     * The result is generated into the "chk" lob that the caller must
     * manage.
     *
     * This is a helper for "dbms_dbfs_content.checkSpi()".
     *
     */

    procedure   checkSpi(
        schema_name         in              varchar2,
        package_name        in              varchar2,
        chk                 in out nocopy   clob);



    /*
     * Utility function: update DBFS context.
     *
     * Internal helper function that modifies the DBFS context (and
     * allows sessions to refresh their internal state on subsequent
     * operations). Invoked by various clients after any significant
     * changes to persistent state.
     *
     */

    procedure   updateCtx(
        suid                in              varchar2    default null);



    /*
     * DBFS export/import procedural actions.
     *
     * For internal use only. See project-5464 for details.
     *
     */

    function    system_info_exp(
        prepost             in          pls_integer,
        connectstring       out nocopy  varchar2,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;

    function    schema_info_exp(
        schema              in          varchar2,
        prepost             in          pls_integer,
        isdba               in          pls_integer,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;

    function    instance_info_exp(
        name                in          varchar2,
        schema              in          varchar2,
        prepost             in          pls_integer,
        isdba               in          pls_integer,
        version             in          varchar2,
        new_block           out         pls_integer)
            return  varchar2;



    /*
     * DBFS export/import support.
     *
     * A one-time action to register the ContentAPI entities with the
     * procedural action infrastructure.
     *
     * The registrations should normally have already occurred
     * implicitly during catalog initialization; however, invoking this
     * procedure (one or more times) explicitly is harmless.
     *
     *
     * The procedure executes like a DDL (i.e. auto-commits before and
     * after its execution).
     *
     */

    procedure   eximRegisterAll;



    /*
     * DBFS export/import support (helper functions).
     *
     * These functions are _strictly_ for internal use in the DBFS
     * export/import infrastructure. Do not even _think_ about using
     * them explicitly.
     *
     */

    procedure   exim_store(
        s_owner             in          varchar2,
        s_name              in          varchar2,
        p_name              in          varchar2,
        p_pkg               in          varchar2,
        created             in          number);
            pragma  supplemental_log_data(
                        exim_store,
                        AUTO);

    procedure   exim_mount(
        s_owner             in          varchar2,
        s_name              in          varchar2,
        s_mount             in          varchar2,
        created             in          number);
            pragma  supplemental_log_data(
                        exim_mount,
                        AUTO);

    procedure   exim_mountp(
        s_owner             in          varchar2,
        s_name              in          varchar2,
        s_mount             in          varchar2,
        propname            in          varchar2,
        propvalue           in          varchar2,
        typecode            in          number);
            pragma  supplemental_log_data(
                        exim_mountp,
                        AUTO);



    /* profiler support */
    procedure   profile_enable;
    procedure   profile_restore;
    procedure   profile_clear;



end;
/

