create TYPE COLDICTREC FORCE AS OBJECT(
  col_name   dbms_id,  -- bug # 19366477 - changed from VARCHAR2(30) to dbms_id
  col_type   number,
  col_def    varchar2(32767),
  col_null   number,
  col_flag   number,
  col_prop   number,
  col_unum   number,
  col_inum   number,
  col_obj    number,
  col_scale  number,
  h_bcnt     number,
  h_pfreq    number,
  col_len    number,
  cu_time    date,
  cu_ep      number,
  cu_ejp     number,
  cu_rp      number,
  cu_lp      number,
  cu_nejp    number,
  cu_np      number
);
/

