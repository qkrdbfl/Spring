create TYPE adr_log_msg_arg_t FORCE AS OBJECT
(
  name       VARCHAR2(64),                      /* log message argument name */
  value      VARCHAR2(128)                     /* log message argument value */
);
/

